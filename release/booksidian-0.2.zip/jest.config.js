const config = {
    verbose: true,
};

module.exports = config;