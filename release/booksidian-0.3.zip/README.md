# booksidian
A Chrome extension to automatically create notes for books
